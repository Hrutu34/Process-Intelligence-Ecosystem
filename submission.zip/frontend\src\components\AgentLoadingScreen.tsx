import React, { useEffect, useState } from 'react';
import './AgentLoadingScreen.css';

interface Props {
  mascotImage?: string;
  fileCount?: number;
  title?: string;
  steps?: StepItem[];
  theme?: 'aqua' | 'yellow' | 'coral';
}

interface StepItem {
  title: string;
  desc: string;
  weight: number;
}

const BASE_STEPS: StepItem[] = [
  { title: 'Ingestion', desc: 'Parsing document streams & reading raw text...', weight: 2500 },
  { title: 'Classification', desc: 'Classifying document type & calibrating confidence...', weight: 5000 },
  { title: 'Extraction', desc: 'Extracting activities, actors, systems & gateways...', weight: 9000 },
  { title: 'Conflict Audit', desc: 'Comparing files & isolating discrepancies...', weight: 8000 },
  { title: 'Normalization', desc: 'Pruning duplicates, validating JSON & sealing DTO graph...', weight: 4000 },
];

export const AgentLoadingScreen: React.FC<Props> = ({
  fileCount = 1,
  title = 'Apple Pie (Extraction) in Progress',
  mascotImage = '/mascots/ApplePie.png',
  steps = BASE_STEPS,
  theme = 'aqua',
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  // Scale step timeouts dynamically based on file count
  const multiplier = Math.max(1, fileCount * 0.85);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (currentStepIndex < steps.length - 1) {
      const duration = steps[currentStepIndex].weight * multiplier;
      timer = setTimeout(() => {
        setCurrentStepIndex((prev) => prev + 1);
      }, duration);
    }
    return () => clearTimeout(timer);
  }, [currentStepIndex, multiplier, steps]);

  return (
    <div className={`agent-loading-card theme-${theme}`}>
      <div className="loading-orbit">
        <div className="inner-pulse" />
        {mascotImage ? (
          <img src={mascotImage} alt="Agent Mascot" className="agent-mascot-img pulsing" />
        ) : (
          <svg viewBox="0 0 100 100" className="grok-mascot">
            <rect className="grok-outer" x="15" y="15" width="70" height="70" rx="16" fill="none" stroke="currentColor" strokeWidth="4" />
            <circle className="grok-inner" cx="50" cy="50" r="12" fill="currentColor" />
            <path className="grok-scanner" d="M 5 50 L 95 50" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" opacity="0.6" />
          </svg>
        )}
      </div>

      <div className="loading-header">
        <div className="status-pill status-pill-centered">
          <span className="status-dot pulsing" />
          PROCESSING {fileCount} DOCUMENT{fileCount > 1 ? 'S' : ''}
          <span className="status-separator">/</span>
          AGENTIC PIPELINE
        </div>
        <h3>{title}</h3>
        <p className="active-step-text">{steps[currentStepIndex].desc}</p>
      </div>

      {/* Connected Track with Validation Ticks */}
      <div className="stepper-container">
        <div className="stepper-track">
          {steps.map((step, idx) => {
            const isCompleted = idx < currentStepIndex;
            const isActive = idx === currentStepIndex;

            return (
              <React.Fragment key={idx}>
                <div className={`step-node ${isCompleted ? 'completed' : ''} ${isActive ? 'active' : ''}`}>
                  <div className="step-circle">
                    {isCompleted ? '✓' : `0${idx + 1}`}
                  </div>
                  <span className="step-label">{step.title}</span>
                </div>

                {idx < steps.length - 1 && (
                  <div className={`step-line ${idx < currentStepIndex ? 'filled' : ''}`} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
};
